
import os
import io
from datetime import datetime
from flask import Flask, render_template, request, redirect, url_for, flash, send_from_directory, jsonify, session
from flask_sqlalchemy import SQLAlchemy
from flask_login import LoginManager, UserMixin, login_user, login_required, logout_user, current_user
from werkzeug.security import generate_password_hash, check_password_hash
from werkzeug.utils import secure_filename
from PIL import Image
import secrets
import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from functools import wraps
import base64
import random
import os
import google.generativeai as genai
import requests

from groq import Groq

client = Groq(api_key="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")


#GROQ_API_KEY = "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"

def generate_chatbot_prompt(user, user_message):
    if user.is_admin:
        reports = Issue.query.order_by(Issue.created_at.desc()).all()
    else:
        reports = Issue.query.filter_by(user_id=user.id).order_by(Issue.created_at.desc()).all()
    
    reports_summary = "\n".join([
        f"ID: {r.id}, Title: {r.title}, Status: {r.status}, Category: {r.category}, Location: {r.location}"
        for r in reports
    ]) or "No reports available."

    # Departments and categories (for site guidance)
    dept_info = "\n".join([f"{d}: {', '.join(cats)}" for d, cats in DEPARTMENT_CATEGORIES.items()])

    prompt = f"""
You are a friendly Civic Issue Assistant AI for a web application.
Your tasks:
- Help the user navigate the site: how to report issues, view dashboards, check assigned tasks.
- Provide information about their own reports.
- Give general guidance about civic issue categories and departments.

User info:
- Name: {user.first_name} {user.last_name}
- Role: {user.role}

    User reports:
    {reports_summary}

    Departments & Categories:
    {dept_info}

    User's message:
    "{user_message}"

    Respond clearly, politely, and helpfully.
    """
    return prompt


DEPARTMENT_CATEGORIES = {
    'Roads Department': ['Road Damage', 'Potholes', 'Sidewalk Issues', 'Street Lights'],
    'Water Department': ['Water Supply', 'Drainage Issues', 'Sewage Problems', 'Flooding'],
    'Electricity Department': ['Electricity', 'Power Outages', 'Street Light Repair', 'Electrical Hazards'],
    'Sanitation Department': ['Sanitation', 'Garbage Collection', 'Public Toilets', 'Cleaning Services'],
    'Parks Department': ['Parks & Recreation', 'Playground Equipment', 'Public Gardens', 'Sports Facilities'],
    'Public Safety Department': ['Public Safety', 'Traffic Issues', 'Security Concerns', 'Emergency Services']
}


app = Flask(__name__)
app.config['SECRET_KEY'] = 'your-secret-key-here-change-in-production'
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///civic_issues.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
app.config['UPLOAD_FOLDER'] = 'static/uploads'
app.config['MAX_CONTENT_LENGTH'] = 16 * 1024 * 1024  # 16MB max file size

# Email configuration (update with your SMTP details)
app.config['MAIL_SERVER'] = 'smtp.gmail.com'
app.config['MAIL_PORT'] = 587
app.config['MAIL_USE_TLS'] = True
app.config['MAIL_USERNAME'] = 'lokeshdevarajan07@gmail.com'
app.config['MAIL_PASSWORD'] = 'vzlxigvsqanryjhx'   # Gmail App Password
app.config['MAIL_DEFAULT_SENDER'] = 'CivicX <lokeshdevarajan07@gmail.com>'

from flask import request, jsonify

DEPT_INFO_SUMMARY = "\n".join([f"{d}: {', '.join(cats)}" for d, cats in DEPARTMENT_CATEGORIES.items()])

@app.route('/chatbot', methods=['POST'])
def chatbot():
    data = request.get_json()
    user_message = data.get("message", "")
    if not user_message:
        return jsonify({"response": "Please provide a message."})

    # Prepare chat history in session
    if 'chat_history' not in session:
        session['chat_history'] = []

    # Build system prompt
    if current_user.is_authenticated:
        # Fetch last 5 reports
        query = Issue.query
        if not current_user.is_admin:
            query = query.filter_by(user_id=current_user.id)
        recent_reports = query.order_by(Issue.created_at.desc()).limit(5).all()
        reports_summary = "\n".join([
            f"ID: {r.id}, Title: {r.title}, Status: {r.status}, Category: {r.category}, Location: {r.location}"
            for r in recent_reports
        ]) or "No recent reports found."

        system_prompt = f"""You are a friendly Civic Issue Assistant AI.
Your tasks:
- Help the user navigate the site: report issues, view dashboards, check assigned tasks.
- Provide info about their own reports.
- Give guidance about civic issue categories and departments.

User info:
- Name: {current_user.first_name} {current_user.last_name}
- Role: {current_user.role}

User's 5 most recent reports:
{reports_summary}

Departments & Categories:
{DEPT_INFO_SUMMARY}
"""
    else:
        system_prompt = f"""You are a friendly Civic Issue Assistant AI.
Your task is to help a guest user (not logged in) who wants guidance about the civic issue reporting site.
Do not include any personal data.
Departments & Categories:
{DEPT_INFO_SUMMARY}
"""

    if not session['chat_history']:
        session['chat_history'].append({"role": "system", "content": system_prompt})

    session['chat_history'].append({"role": "user", "content": user_message})

    try:
        completion = client.chat.completions.create(
            model="llama-3.1-8b-instant",
            messages=session['chat_history'],
            temperature=0.7,
            max_completion_tokens=512,
            top_p=1
        )

        # Extract AI response text
        ai_message = completion.choices[0].message.content

        # Append AI response to session history
        session['chat_history'].append({"role": "assistant", "content": ai_message})

        return jsonify({"response": ai_message})

    except Exception as e:
        print(f"Groq API error: {e}")
        session.pop('chat_history', None)
        return jsonify({"response": "Sorry, the AI assistant encountered an error. Let's start over."})



db = SQLAlchemy(app)
login_manager = LoginManager(app)
login_manager.login_view = 'login'

os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)

class User(db.Model, UserMixin):
    id = db.Column(db.Integer, primary_key=True)
    worker_id = db.Column(db.String(20), unique=True, nullable=True)  # NEW
    first_name = db.Column(db.String(100), nullable=True)
    last_name = db.Column(db.String(100), nullable=True)
    username = db.Column(db.String(150), unique=True, nullable=False)
    email = db.Column(db.String(150), unique=True, nullable=False)
    password = db.Column(db.String(200), nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    role = db.Column(db.String(20), default='citizen')   # admin, worker, citizen
    department = db.Column(db.String(100), nullable=True)
    is_active = db.Column(db.Boolean, default=True)

    is_verified = db.Column(db.Boolean, default=False)
    otp_code = db.Column(db.String(6), nullable=True)
    otp_expiry = db.Column(db.DateTime, nullable=True)

    def set_password(self, password):
        self.password = generate_password_hash(password)

    def check_password(self, password):
        return check_password_hash(self.password, password)

    @property
    def is_admin(self):
        return self.role == 'admin'

    @property
    def is_worker(self):
        return self.role == 'worker'

    @property
    def is_citizen(self):
        return self.role == 'citizen'


class Issue(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(200), nullable=False)
    description = db.Column(db.Text, nullable=False)
    category = db.Column(db.String(100), nullable=False)
    location = db.Column(db.String(200), nullable=False)
    latitude = db.Column(db.Float)
    longitude = db.Column(db.Float)
    image_path = db.Column(db.String(300))
    status = db.Column(db.String(50), default='Reported') 
    priority = db.Column(db.String(20), default='Medium') 
    estimated_cost = db.Column(db.Float, default=0.0)
    allocated_funds = db.Column(db.Float, default=0.0)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    assigned_to = db.Column(db.Integer, db.ForeignKey('user.id')) 
    reporter = db.relationship('User', foreign_keys=[user_id])
    assigned_worker = db.relationship('User', foreign_keys=[assigned_to])
    assigned_department = db.Column(db.String(100))
    admin_notes = db.Column(db.Text)
    worker_notes = db.Column(db.Text)
    completion_date = db.Column(db.DateTime)

def send_email(to_email, subject, body):
    try:
        msg = MIMEMultipart()
        msg['From'] = app.config['MAIL_DEFAULT_SENDER']
        msg['To'] = to_email
        msg['Subject'] = subject
        msg.attach(MIMEText(body, 'html'))
        
        server = smtplib.SMTP(app.config['MAIL_SERVER'], app.config['MAIL_PORT'])
        server.starttls()
        server.login(app.config['MAIL_USERNAME'], app.config['MAIL_PASSWORD'])
        server.send_message(msg)
        server.quit()
        print(f"Email sent successfully to {to_email}")
        return True
    except Exception as e:
        print(f"Email error: {e}")
        return False
    
@app.route('/resend_otp', methods=['GET'])
def resend_otp():
    email = request.args.get('email')
    if not email:
        flash('Email is required to resend OTP.', 'warning')
        return redirect(url_for('register'))

    user = User.query.filter_by(email=email).first()
    if not user:
        flash('User not found.', 'danger')
        return redirect(url_for('register'))

    if user.is_verified:
        flash('This account is already verified.', 'info')
        return redirect(url_for('login'))

    otp = str(random.randint(100000, 999999))
    expiry = datetime.utcnow() + timedelta(minutes=5)
    user.otp_code = otp
    user.otp_expiry = expiry
    db.session.commit()

    if send_otp_email(user.email, otp):
        flash('A new OTP has been sent to your email.', 'success')
    else:
        flash('Failed to send OTP. Please try again later.', 'danger')

    return redirect(url_for('verify_otp', email=user.email))

    

def send_otp_email(to_email, otp):
    subject = "CivicX OTP"
    body = f"""
    <div style="
        font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        background-color: #f4f7f9; 
        padding: 40px 0; 
    ">
        <div style="
            max-width: 500px; 
            margin: auto; 
            background-color: #ffffff; 
            border-radius: 12px; 
            box-shadow: 0 4px 12px rgba(0,0,0,0.1); 
            overflow: hidden;
            border-left: 6px solid #00bcd4;
        ">
            <div style="
                background-color: #00bcd4; 
                padding: 20px; 
                text-align: center;
                color: #ffffff;
                font-size: 24px;
                font-weight: bold;
            ">
                CivicX
            </div>
            <div style="padding: 30px; color: #333333; line-height: 1.5;">
                <h3 style="color:#007c91; margin-top:0;">Email Verification</h3>
                <p>Hello,</p>
                <p>Your OTP verification code is:</p>
                <p style="
                    background-color:#e0f7fa; 
                    color:#004d56; 
                    font-size:24px; 
                    font-weight:bold; 
                    text-align:center; 
                    padding:15px; 
                    border-radius:8px;
                    margin:20px 0;
                    letter-spacing:3px;
                ">{otp}</p>
                <p style="color:#555555; font-size: 14px;">This code will expire in 5 minutes.</p>
            </div>
            <div style="background-color:#f4f7f9; padding:15px; text-align:center; font-size:12px; color:#999999;">
                &copy; {datetime.now().year} CivicX. All rights reserved.
            </div>
        </div>
    </div>
    """
    return send_email(to_email, subject, body)




def save_image_from_data_url(image_data):
    try:
        header, data = image_data.split(',', 1)
        image_bytes = base64.b64decode(data)
        
        image = Image.open(io.BytesIO(image_bytes))
        
        random_hex = secrets.token_hex(8)
        picture_fn = random_hex + '.jpg'
        picture_path = os.path.join(app.config['UPLOAD_FOLDER'], picture_fn)
        
        output_size = (800, 600)
        image.thumbnail(output_size)
        
        if image.mode in ('RGBA', 'P'):
            image = image.convert('RGB')
            
        image.save(picture_path, 'JPEG', quality=85)
        
        return picture_fn
    except Exception as e:
        print(f"Error saving image: {e}")
        return None

def get_department_for_category(category):
    for department, categories in DEPARTMENT_CATEGORIES.items():
        if category in categories:
            return department
    return "General Department"  # Default department

def assign_issue_to_department(issue):
    department = get_department_for_category(issue.category)
    issue.assigned_department = department
    
    department_workers = User.query.filter_by(
        department=department, 
        role='worker',
        is_active=True
    ).all()
    
    if department_workers:
        assigned_worker = random.choice(department_workers)
        issue.assigned_to = assigned_worker.id
        issue.status = 'Assigned'
        
        email_body = f"""
        <h2>New Issue Assigned to You</h2>
        <p>Hello {assigned_worker.first_name},</p>
        <p>A new issue has been automatically assigned to you in the {department}:</p>
        <p><strong>Title:</strong> {issue.title}</p>
        <p><strong>Category:</strong> {issue.category}</p>
        <p><strong>Location:</strong> {issue.location}</p>
        <p><strong>Priority:</strong> {issue.priority}</p>
        <p>Please review and address this issue in your dashboard.</p>
        """
        send_email(assigned_worker.email, 'New Issue Assigned', email_body)
        
        return assigned_worker
    else:
        issue.status = 'Reported'
        return None

def admin_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if not current_user.is_admin:
            flash('You need to be an admin to access this page.', 'danger')
            return redirect(url_for('dashboard'))
        return f(*args, **kwargs)
    return decorated_function

def worker_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if not current_user.is_worker and not current_user.is_admin:
            flash('You need to be a worker to access this page.', 'danger')
            return redirect(url_for('dashboard'))
        return f(*args, **kwargs)
    return decorated_function

@login_manager.user_loader
def load_user(user_id):
    return User.query.get(int(user_id))

@app.route('/')
def index():
    return render_template('index.html')


@app.route('/worker/login', methods=['GET', 'POST'])
def worker_login():
    if current_user.is_authenticated and current_user.role == 'worker':
        return redirect(url_for('worker_dashboard'))

    if request.method == 'POST':
        worker_id = request.form.get('worker_id')
        password = request.form.get('password')

        worker = User.query.filter_by(worker_id=worker_id, role='worker').first()

        if worker and worker.check_password(password):
            login_user(worker)
            return redirect(url_for('worker_dashboard'))
        else:
            flash('Invalid ID or password', 'danger')

    return render_template('worker_login.html')



@app.route('/worker/dashboard')
@login_required
@worker_required
def worker_dashboard():
    status_filter = request.args.get("status", "all")
    page = request.args.get("page", 1, type=int)
    per_page = 10

    query = Issue.query.filter(Issue.assigned_worker == current_user)


    if status_filter != "all":
        query = query.filter_by(status=status_filter)

    issues = query.order_by(Issue.created_at.desc()).paginate(page=page, per_page=per_page)

    return render_template(
        "worker_dashboard.html",
        tasks=issues.items, 
        status_filter=status_filter
    )




@app.route('/worker/issue/<int:task_id>')
@login_required
@worker_required
def worker_task_detail(task_id):
    task = Issue.query.get_or_404(task_id)
    
    if task.assigned_department != current_user.department and task.assigned_to != current_user.id:
        flash('You do not have permission to view this issue.', 'danger')
        return redirect(url_for('worker_dashboard'))

    return render_template('worker_task_detail.html', task=task)

@app.route('/assign_worker/<int:issue_id>', methods=['POST'])
@login_required
@admin_required
def assign_worker(issue_id):
    
    worker_id = request.form.get('worker_id')
    issue = Issue.query.get_or_404(issue_id)

    if worker_id:
        try:
            worker_id = int(worker_id)
            worker = User.query.get(worker_id)
        except ValueError:
            worker = None

        if worker and worker.role == 'worker':
            issue.assigned_worker = worker
            issue.status = 'In Progress'
            db.session.commit()
            flash(f'Worker {worker.id} assigned successfully!', 'success')
        else:
            flash('Invalid Worker ID.', 'danger')
    return redirect(url_for('admin_dashboard'))



@app.route('/admin/add-worker', methods=['GET', 'POST'])
@login_required
@admin_required
def add_worker():
    departments = list(DEPARTMENT_CATEGORIES.keys())

    if request.method == 'POST':
        worker_id = request.form.get('worker_id')
        password = request.form.get('password')
        department = request.form.get('department')

        existing_worker = User.query.filter_by(worker_id=worker_id).first()
        if existing_worker:
            flash('Worker ID already exists!', 'danger')
            return redirect(url_for('add_worker'))

        hashed_password = generate_password_hash(password, method='scrypt')

        new_worker = User(
            worker_id=worker_id,
            username=worker_id,
            first_name='Worker',
            last_name=worker_id,
            email=f'{worker_id}@example.com',
            password=hashed_password,
            role='worker',
            department=department,
            created_at=datetime.now(),
            is_active=True,
            is_verified=False
        )

        db.session.add(new_worker)
        db.session.commit()
        flash(f'Worker {worker_id} added successfully!', 'success')
        return redirect(url_for('add_worker'))

    return render_template('add_worker.html', departments=departments)



from datetime import datetime, timedelta
import random

@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        first_name = request.form['first_name']
        last_name = request.form['last_name']
        email = request.form['email']
        password = generate_password_hash(request.form['password'], method='pbkdf2:sha256')

        username = email.split('@')[0]

        if User.query.filter_by(email=email).first():
            flash('Email already registered.')
            return redirect(url_for('register'))

        otp = str(random.randint(100000, 999999))
        expiry = datetime.utcnow() + timedelta(minutes=5)

        new_user = User(
            first_name=first_name,
            last_name=last_name,
            username=username,
            email=email,
            password=password,
            otp_code=otp,
            otp_expiry=expiry,
            is_verified=False,
            role='citizen'
        )
        db.session.add(new_user)
        db.session.commit()

        send_otp_email(email, otp)

        flash('OTP sent to your email. Please verify within 5 minutes.')
        return redirect(url_for('verify_otp', email=email))

    return render_template('register.html')



@app.route('/verify_otp', methods=['GET', 'POST'])
def verify_otp():
    # This line now checks the form first, then the URL.
    email = request.form.get('email') or request.args.get('email')

    if not email:
        flash('Invalid verification link.', 'danger')
        return redirect(url_for('login'))

    user = User.query.filter_by(email=email).first()
    if not user:
        flash('User not found.', 'danger')
        return redirect(url_for('register'))

    if request.method == 'POST':
        otp_entered = request.form.get('otp')

        if user.otp_code == otp_entered and user.otp_expiry > datetime.utcnow():
            user.is_verified = True
            user.otp_code = None
            user.otp_expiry = None
            db.session.commit()
            flash('Account verified! You can now log in.', 'success')
            return redirect(url_for('login'))
        else:
            flash('Invalid or expired OTP. Please try again or resend.', 'danger')
            # Stay on the same page but with the error message
            return render_template('verify_otp.html', email=email) 
    
    # This handles the initial GET request to the page
    return render_template('verify_otp.html', email=email)


@app.route('/login', methods=['GET', 'POST'])
def login():
    if current_user.is_authenticated:
        return redirect(url_for('dashboard'))
    
    if request.method == 'POST':
        email = request.form.get('email')
        password = request.form.get('password')
        remember = True if request.form.get('remember') else False
        
        user = User.query.filter_by(email=email, is_active=True).first()
        
        if not user or not user.check_password(password):
            flash('Invalid email or password.', 'danger')
            return redirect(url_for('login'))
        
        if not user.is_verified:
            flash('Please verify your account with OTP before logging in.')
            return redirect(url_for('verify_otp', email=user.email))

        
        login_user(user, remember=remember)
        
        email_body = f"""
<div style="
    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    background-color: #f4f7f9; 
    padding: 40px 0; 
">
    <div style="
        max-width: 500px; 
        margin: auto; 
        background-color: #ffffff; 
        border-radius: 12px; 
        box-shadow: 0 4px 12px rgba(0,0,0,0.1); 
        overflow: hidden;
        border-left: 6px solid #00bcd4;
    ">
        <div style="
            background-color: #00bcd4; 
            padding: 20px; 
            text-align: center;
            color: #ffffff;
            font-size: 24px;
            font-weight: bold;
        ">
            CivicX
        </div>
        <div style="padding: 30px; color: #333333; line-height: 1.5;">
            <h3 style="color:#007c91; margin-top:0;">Login Notification</h3>
            <p>Hello <strong>{user.first_name}</strong>,</p>
            <p>You have successfully logged into your <strong>Civic Issue Reporter</strong> account.</p>
        </div>
        <div style="background-color:#f4f7f9; padding:15px; text-align:center; font-size:12px; color:#999999;">
            &copy; {datetime.now().year} CivicX. All rights reserved.
        </div>
    </div>
</div>
"""
        send_email(user.email, 'Login Notification', email_body)


        
        flash('Logged in successfully!', 'success')
        
        if user.is_admin:
            return redirect(url_for('admin_dashboard'))
        elif user.is_worker:
            return redirect(url_for('worker_dashboard'))
        else:
            return redirect(url_for('dashboard'))
    
    return render_template('login.html')

@app.route('/logout')
@login_required
def logout():
    role = current_user.role
    logout_user()
    flash('You have been logged out.', 'info')

    if role == 'admin':
        return redirect(url_for('login'))  # Or your admin login route
    elif role == 'worker':
        return redirect(url_for('worker_login'))
    else:
        return redirect(url_for('login'))  # Citizen login


@app.route('/reports')
def public_reports():
    """Public page to display all civic issues without requiring login."""
    page = request.args.get('page', 1, type=int)
    per_page = 9 

    # Query all issues, ordered by the most recent
    issues = Issue.query.order_by(Issue.created_at.desc()).paginate(page=page, per_page=per_page)
    
    return render_template('reports.html', issues=issues, title="Public Reports")

@app.route('/dashboard')
@login_required
def dashboard():
    page = request.args.get('page', 1, type=int)
    per_page = 10
    
    if current_user.is_admin:
        issues = Issue.query.order_by(Issue.created_at.desc()).paginate(page=page, per_page=per_page)
    elif current_user.is_worker:
        assigned_issues = Issue.query.filter_by(assigned_to=current_user.id)
        all_issues = Issue.query.order_by(Issue.created_at.desc())
        issues = all_issues.paginate(page=page, per_page=per_page)
    else:
        issues = Issue.query.filter_by(user_id=current_user.id).order_by(Issue.created_at.desc()).paginate(page=page, per_page=per_page)
    
    return render_template('dashboard.html', issues=issues)

@app.route('/report', methods=['GET', 'POST'])
@login_required
def report_issue():
    if request.method == 'POST':
        title = request.form.get('title')
        description = request.form.get('description')
        category = request.form.get('category')
        location = request.form.get('location')
        latitude = request.form.get('latitude')
        longitude = request.form.get('longitude')
        image_data = request.form.get('image_data')
        priority = request.form.get('priority', 'Medium')
        
        image_path = save_image_from_data_url(image_data) if image_data else None
        
        issue = Issue(
            title=title,
            description=description,
            category=category,
            location=location,
            latitude=float(latitude) if latitude else None,
            longitude=float(longitude) if longitude else None,
            image_path=image_path,
            user_id=current_user.id,
            priority=priority
        )
        
        db.session.add(issue)
        db.session.commit()
        
        assigned_worker = assign_issue_to_department(issue)
        db.session.commit()
        
        admins = User.query.filter_by(role='admin', is_active=True).all()
        for admin in admins:
            email_body = f"""
            <h2>New Civic Issue Reported</h2>
            <p>A new issue has been reported by {current_user.first_name} {current_user.last_name}:</p>
            <p><strong>Title:</strong> {title}</p>
            <p><strong>Category:</strong> {category}</p>
            <p><strong>Location:</strong> {location}</p>
            <p><strong>Assigned Department:</strong> {issue.assigned_department}</p>
            """
            if assigned_worker:
                email_body += f"""
                <p><strong>Assigned Worker:</strong> {assigned_worker.first_name} {assigned_worker.last_name}</p>
                """
            else:
                email_body += """
                <p><strong>Status:</strong> Awaiting assignment to a worker</p>
                """

            email_body += """
                <p>Please review it in the admin dashboard.</p>
            """
            send_email(admin.email, 'New Civic Issue Reported', email_body)
        
        if assigned_worker:
            flash(f'Issue reported successfully! Assigned to {assigned_worker.first_name} in {issue.assigned_department}.', 'success')
        else:
            flash('Issue reported successfully! Awaiting assignment to a department worker.', 'info')
            
        return redirect(url_for('dashboard'))
    
    return render_template('report_issue.html', categories=sum(DEPARTMENT_CATEGORIES.values(), []))

@app.route('/issue/<int:issue_id>')
@login_required
def issue_detail(issue_id):
    issue = Issue.query.get_or_404(issue_id)
    
    if issue.user_id != current_user.id and not current_user.is_admin and issue.assigned_to != current_user.id:
        flash('You do not have permission to view this issue.', 'danger')
        return redirect(url_for('dashboard'))
    
    return render_template('issue_detail.html', issue=issue)

@app.route('/issue/<int:issue_id>/update', methods=['POST'])
@login_required
@worker_required
def update_issue(issue_id):
    issue = Issue.query.get_or_404(issue_id)
    
    if issue.assigned_to != current_user.id and not current_user.is_admin:
        flash('You are not assigned to this issue.', 'danger')
        return redirect(url_for('dashboard'))
    
    issue.status = request.form.get('status')
    issue.worker_notes = request.form.get('worker_notes')
    
    if issue.status == 'Resolved':
        issue.completion_date = datetime.utcnow()
    
    db.session.commit()
    
    email_body = f"""
    <h2>Your Issue Status Has Been Updated</h2>
    <p>Hello {issue.reporter.first_name},</p>
    <p>The status of your issue "{issue.title}" has been updated to <strong>{issue.status}</strong>.</p>
    <p><strong>Worker Notes:</strong> {issue.worker_notes or 'No notes provided.'}</p>
    <p>You can view the updated details in your dashboard.</p>
    """
    send_email(issue.reporter.email, 'Issue Status Updated', email_body)
    
    flash('Issue updated successfully!', 'success')
    return redirect(url_for('issue_detail', issue_id=issue.id))

@app.route('/admin/dashboard')
@login_required
@admin_required
def admin_dashboard():
    status_filter = request.args.get("status", "all")
    priority_filter = request.args.get("priority", "all")
    page = request.args.get("page", 1, type=int)
    per_page = 10

    query = Issue.query

    if status_filter != "all":
        query = query.filter_by(status=status_filter)
    if priority_filter != "all":
        query = query.filter_by(priority=priority_filter)

    issues = query.order_by(Issue.created_at.desc()).paginate(page=page, per_page=per_page)

    for issue in issues.items:
        issue.department_workers = User.query.filter_by(role='worker', department=issue.assigned_department).all()

    total_issues = Issue.query.count()
    pending_issues = Issue.query.filter_by(status="Pending").count()
    in_progress_issues = Issue.query.filter_by(status="In Progress").count()
    resolved_issues = Issue.query.filter_by(status="Resolved").count()

    return render_template(
        "admin_dashboard.html",
        issues=issues,
        status_filter=status_filter,
        priority_filter=priority_filter,
        total_issues=total_issues,
        pending_issues=pending_issues,
        in_progress_issues=in_progress_issues,
        resolved_issues=resolved_issues
    )



@app.route('/admin/issue/<int:issue_id>', methods=['GET', 'POST'])
@login_required
@admin_required
def admin_issue_detail(issue_id):
    issue = Issue.query.get_or_404(issue_id)
    workers = User.query.filter_by(role='worker', is_active=True).all()
    
    if request.method == 'POST':
        issue.status = request.form.get('status')
        issue.priority = request.form.get('priority')
        issue.allocated_funds = float(request.form.get('allocated_funds', 0))
        issue.estimated_cost = float(request.form.get('estimated_cost', 0))
        issue.admin_notes = request.form.get('admin_notes')
        
        assigned_to = request.form.get('assigned_to')
        if assigned_to and assigned_to != 'none':
            issue.assigned_to = int(assigned_to)
            issue.status = 'Assigned'
            
            worker = User.query.get(assigned_to)
            email_body = f"""
            <h2>New Issue Assigned to You</h2>
            <p>Hello {worker.first_name},</p>
            <p>You have been assigned a new issue:</p>
            <p><strong>Title:</strong> {issue.title}</p>
            <p><strong>Category:</strong> {issue.category}</p>
            <p><strong>Location:</strong> {issue.location}</p>
            <p><strong>Priority:</strong> {issue.priority}</p>
            <p>Please review it in your dashboard.</p>
            """
            send_email(worker.email, 'New Issue Assigned', email_body)
        elif assigned_to == 'none':
            issue.assigned_to = None
            issue.status = 'Reported'
        
        issue.updated_at = datetime.utcnow()
        
        db.session.commit()
        
        # Notify reporter about status update
        email_body = f"""
        <h2>Your Issue Status Has Been Updated</h2>
        <p>Hello {issue.reporter.first_name},</p>
        <p>The status of your issue "{issue.title}" has been updated to <strong>{issue.status}</strong>.</p>
        <p><strong>Admin Notes:</strong> {issue.admin_notes or 'No notes provided.'}</p>
        <p>You can view the updated details in your dashboard.</p>
        """
        send_email(issue.reporter.email, 'Issue Status Updated', email_body)
        
        flash('Issue updated successfully!', 'success')
        return redirect(url_for('admin_issue_detail', issue_id=issue.id))
    
    return render_template('admin_issue_detail.html', issue=issue, workers=workers)

@app.route('/admin/workers')
@login_required
@admin_required
def admin_workers():
    department_filter = request.args.get('department', 'all')
    
    query = User.query.filter_by(role='worker', is_active=True)
    
    if department_filter != 'all':
        query = query.filter_by(department=department_filter)
    
    workers = query.all()
    
    for worker in workers:
        worker.assigned_count = Issue.query.filter_by(assigned_to=worker.id).count()
        worker.resolved_count = Issue.query.filter_by(assigned_to=worker.id, status='Resolved').count()
        worker.in_progress_count = Issue.query.filter_by(assigned_to=worker.id, status='In Progress').count()
    
    return render_template('admin_workers.html', 
                         workers=workers, 
                         departments=list(DEPARTMENT_CATEGORIES.keys()),
                         department_filter=department_filter)


@app.route('/admin/worker/<int:worker_id>/delete', methods=['POST'])
@login_required
@admin_required
def delete_worker(worker_id):
    worker = User.query.get_or_404(worker_id)
    
    if worker.role != 'worker':
        flash('This user is not a worker.', 'danger')
        return redirect(url_for('admin_workers'))
    
    worker.is_active = False
    
    issues_to_reassign = Issue.query.filter_by(assigned_to=worker.id, status='Assigned').all()
    
    for issue in issues_to_reassign:
        # Try to reassign to another worker in the same department
        department_workers = User.query.filter_by(
            department=worker.department, 
            role='worker',
            is_active=True
        ).filter(User.id != worker.id).all()
        
        if department_workers:
            new_worker = random.choice(department_workers)
            issue.assigned_to = new_worker.id
            
            # Notify the new assigned worker
            email_body = f"""
            <h2>Issue Reassigned to You</h2>
            <p>Hello {new_worker.first_name},</p>
            <p>An issue has been reassigned to you:</p>
            <p><strong>Title:</strong> {issue.title}</p>
            <p><strong>Category:</strong> {issue.category}</p>
            <p><strong>Location:</strong> {issue.location}</p>
            <p><strong>Reason:</strong> Previous worker is no longer available</p>
            <p>Please review and address this issue in your dashboard.</p>
            """
            send_email(new_worker.email, 'Issue Reassigned', email_body)
        else:
            issue.assigned_to = None
            issue.status = 'Reported'
    
    db.session.commit()
    
    flash('Worker account deactivated successfully!', 'success')
    return redirect(url_for('admin_workers'))


@app.route('/uploads/<filename>')
def uploaded_file(filename):
    return send_from_directory(app.config['UPLOAD_FOLDER'], filename)

# API endpoint to get department workers
@app.route('/api/department/<department>/workers')
@login_required
@admin_required
def get_department_workers(department):
    workers = User.query.filter_by(department=department, role='worker', is_active=True).all()
    workers_data = [{'id': w.id, 'name': f'{w.first_name} {w.last_name}'} for w in workers]
    return jsonify(workers_data)

@app.errorhandler(404)
def not_found_error(error):
    return render_template('404.html'), 404

@app.errorhandler(500)
def internal_error(error):
    db.session.rollback()
    return render_template('500.html'), 500

@app.context_processor
def utility_processor():
    def get_status_class(status):
        status_classes = {
            'Reported': 'secondary',
            'Assigned': 'info',
            'In Progress': 'warning',
            'Resolved': 'success',
            'Rejected': 'danger'
        }
        return status_classes.get(status, 'secondary')
    
    def get_priority_class(priority):
        priority_classes = {
            'Low': 'success',
            'Medium': 'warning',
            'High': 'danger',
            'Critical': 'dark'
        }
        return priority_classes.get(priority, 'secondary')
    
    def format_date(value, format='%Y-%m-%d'):
        if value is None:
            return ""
        return value.strftime(format)
    
    return dict(get_status_class=get_status_class, get_priority_class=get_priority_class, format_date=format_date)

with app.app_context():
    db.create_all()
    
    if not User.query.filter_by(email='testsolitary@gmail.com').first():
        admin = User(
            username='admin',
            email='testsolitary@gmail.com',
            first_name='Admin',
            last_name='User',
            role='admin',
            is_verified=True 
        )
        admin.set_password('admin123')
        db.session.add(admin)
        db.session.commit()

if __name__ == '__main__':
    app.run(host="0.0.0.0", debug=False)